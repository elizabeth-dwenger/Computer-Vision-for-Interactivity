#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofSetFrameRate(60);
    
    direction = 1;

    gui.setup();
    gui.add(guiSlider.setup("low threshold", 50, 0, 100));

    line.load("ramp.jpg"); //sharp.jpg; wavy.jpg; ramp.jpg
    line.setImageType(OF_IMAGE_COLOR);
    mat = toCv(line);
    
    cvtColor(mat, mat, CV_BGR2GRAY);
    GaussianBlur(mat, mat, 3);
    Canny(mat, cannyEdge, guiSlider, guiSlider * 2);

    bool found = false;
    for (int c = 0; c < cannyEdge.cols; c++) {
        if (found) {
            break;
        }
        for (int r = cannyEdge.rows - 1; r >= 0 ; r--) {
            if (cannyEdge.at<uchar>(r,c)) {
                found = true;
                posX = c;
                posY = r;
                break;
            }
        }
    }
}

//--------------------------------------------------------------
void ofApp::update(){

    bool found = false;
    for (int i = 9; i > 0; i--) {
        int newX = direction == 1 ? posX + 1 : posX - 1;
        int newY = direction == 1 ? posY + (5 - i) : posY + (i - 5);
        if (cannyEdge.at<uchar>(newY, newX)) {
            posY = newY;
            posX = newX;
            found = true;
            break;
        }
    }
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetColor(255, 255, 255);
    line.draw(0, 0);
    ofFill();
    ofSetColor(0, 0, 0);
    ofDrawCircle(posX, posY, 15);
    gui.draw();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
