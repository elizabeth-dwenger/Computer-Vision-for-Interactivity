#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    gui.setup();
    gui.add(guiSlider.setup("Threshold of Edge Detection", 50, 0, 100));
    currentVideo.initGrabber(320,240);
}

//--------------------------------------------------------------
void ofApp::update(){
    currentVideo.update();

    if (currentVideo.isFrameNew()) {
        imgCam.setFromPixels(currentVideo.getPixels());
        matCurrentCam = toCv(imgCam);
        matCam = toCv(imgCam);
        
        cvtColor(matCam, matCam, CV_BGR2GRAY);
        GaussianBlur(matCam, matCam, 3);
        Canny(matCam, matCam, guiSlider, guiSlider * 2);
        HoughCircles(matCam, circle_position, CV_HOUGH_GRADIENT, 2, 50, guiSlider * 2, 100, 30, 47);
    }
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(255, 255, 255);
    ofSetColor(255);
    drawMat(matCurrentCam, 0, 0);
    for (int i = 0; i < circle_position.size(); i++) {
        ofSetColor(255, 255, 255);
        ofDrawCircle(circle_position[i][0], circle_position[i][1], circle_position[i][2]);

        ofSetColor(0, 0, 0);
        ofDrawCircle(circle_position[i][0], circle_position[i][1], circle_position[i][2]/2);
    }
    gui.draw();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
